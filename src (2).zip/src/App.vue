<template>
  <section>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <img class="navbar-brand kep" src="../src/assets/logo.png" href="/" />
      <button
        class="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarNavDropdown"
        aria-controls="navbarNavDropdown"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
          <li class="nav-item active">
            <a class="nav-link" href="/"
              >Főoldal <span class="sr-only">(current)</span></a
            >
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/termekek">Termékek</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/rolunk">Rólunk</a>
          </li>
          <li class="nav-item dropdown">
            <a
              class="nav-link dropdown-toggle"
              href="#"
              id="navbarDropdownMenuLink"
              data-toggle="dropdown"
              aria-haspopup="true"
              aria-expanded="false"
            >
              Felhasználó
            </a>
            <!--Bejelentkezoresz:D-->
            <div
              class="dropdown-menu bg-dark dropdown-dark text-light"
              id="csere"
              aria-labelledby="navbarDropdownMenuLink"
            >
              <h2 id="statebe" v-if="!logged">Bejelentkezés</h2>
              <div v-else>
                <h2 id="statebe" style="font-size: 20px" class="centered">
                  Bejelentkezett felhasználó
                </h2>
                <img
                  class="profilkep"
                  :src="'data:image/png;base64,' + this.$store.state.Image"
                />
                <p
                  class="text-center"
                >
                  {{ this.$store.state.teljesNev }}
                  <p
                  style="
                    font-size: 12px;
                    color: gray;
                    text-decoration: initial;
                    margin: auto;
                    width:50%;
                  "
                >
                  &nbsp;@{{ this.$store.state.felhasznaloNev }}
                </p>
              </p>
                
              </div>

              <form class="px-4 py-3">
                <div class="form-group" v-if="!logged">
                  <label class="centered" for="exampleDropdownFormEmail1"
                    >Felhasználói adatok</label
                  >
                  <input
                    type="text"
                    class="form-control"
                    id="exampleDropdownFormEmail1"
                    placeholder="user1234"
                    v-model="FelhasznaloNev"
                  />
                </div>
                <div class="form-group" v-if="!logged">
                  <label for="exampleDropdownFormPassword1">Jelszó</label>
                  <input
                    type="password"
                    class="form-control"
                    id="exampleDropdownFormPassword1"
                    placeholder="Jelszó"
                    v-model="Jelszo"
                  />
                </div>
                <div id="error"></div>
                <button
                  type="button"
                  class="btn btn-outline-info"
                  v-if="!logged"
                  @click="loginClick(FelhasznaloNev, Jelszo)"
                >
                  Bejelentkezés
                </button>
                <button
                  type="submit"
                  class="btn btn-outline-info"
                  v-else
                  @click="logoutClick()"
                >
                  Kijelentkezés
                </button>
              </form>
              <a href="/register" class="dropdown-item loglink" v-if="!logged">
                Regisztráció
              </a>
              <a href="/passreset" class="dropdown-item loglink" v-if="!logged">
                Elfelejtetted a jelszót?
              </a>
            </div>
          </li>
        </ul>
      </div>
    </nav>
  </section>
  <section class="bg-dark opacity-25">
    <router-view></router-view>
  </section>
</template>

<style lang="css">
.kep {
  width: 10%;
}
.loglink {
  color: rgba(255, 255, 255, 0.5);
}
html {
  background-color: #343a40;
}
</style>
<script>
import axios from "axios";
import sha256 from "sha256";
import { mapMutations } from "vuex";

export default {
  name: "FelhasznalokView",
  props: {
    msg: String,
  },
  components: {},
  data() {
    return {
      logged: this.$store.state.logged,
      userName: "a",
      lekertSalt: "",
      password: "a",
      tomb: [],
      sikeresBejelentkezes: false,
      felhasznalok: [],
      felhasznalokSzuroNelkul: [],
      felhasznalokSzama: 0,
      Image: this.$store.state.API_IMAGE_URL,
      modalTitle: "Új felhasználó hozzáadása",
      felhasznaloAdatFNevFilter: "",
    };
  },
  computed: mapMutations(["logout"]),
  data() {
    return {
      FelhasznaloNev: "",
      Jelszo: "",
      logged: this.$store.state.logged,
      aktiv: this.$store.state.aktiv,
    };
  },
  methods: {
    refreshData() {},
    closeClick() {
      this.$router.push("/");
    },
    logoutClick() {
      this.logout;
      this.logged = false;
      this.felhasznaloNev = "";
      this.closeClick();
    },
    loginClick(FelhasznaloNev, Jelszo) {
      axios
        .post(this.$store.state.API_URL + "Login/SaltRequest/" + FelhasznaloNev) // https://192.168.50.39:7148/Login/u1/p1?username=u1
        .then((response) => {
          let lekertSalt = response.data;
          let tmpHash = sha256(Jelszo + lekertSalt).toString();
          let url =
            this.$store.state.API_URL +
            "Login?nev=" +
            FelhasznaloNev +
            "&tmpHash=" +
            tmpHash;
          axios
            .post(url)
            .then((response) => {
              if (response.status == 200) {
                let d = response.data;
                var data = JSON.parse(d);
                if (data.Jogosultsag != "-1") {
                  this.logged = true;
                  this.$store.state.logged = true;
                  this.$store.state.Uid = data.Uid;
                  this.$store.state.teljesNev = data.TeljesNev;
                  this.$store.state.jogosultsag = data.Jogosultsag;
                  this.$store.state.Image = data.Image;
                  this.$store.state.felhasznaloNev = FelhasznaloNev;
                  alert(
                    "Sikeres bejelentkezés: " + this.$store.state.teljesNev
                  );
                  document.getElementById("error").innerHTML = "";
                  //console.log(response.data)
                  //console.log(tomb)
                  this.refreshData();
                  this.closeClick();
                } else {
                  document.getElementById("error").innerHTML =
                    "<p style='color:red'>Hibás Jelszó!</p>";
                }
              } else {
                document.getElementById("error").innerHTML =
                  "<p style='color:red'>Inaktív felhasználó/Hibás felhasználónév!</p>";
              }
            })
            .catch((error) => {
              alert(error);
            });
        })
        .catch((error) => {
          document.getElementById("error").innerHTML =
            "<p style='color:red'>Hibás/nincs ilyen, felhasználónév!</p>";

          if (error.response.status == 400) {
            alert(error.response.data);
          } else {
            document.getElementById("error").innerHTML =
              "<p style='color:red'>Inaktív felhasználó/Hibás felhasználónév!</p>";
          }
        });
    },
  },
  mounted: function () {
    this.refreshData();
  },
};
</script>
<style>
.centered {
  text-align: center;
}

.profilkep {
  border: 4px solid #d439dc;
  display: block;
  margin-left: auto;
  margin-right: auto;
  padding: 2px;
  border-radius: 50%;
  border-top-color: #22daff;
  border-left-color: #22daff;
  width: 100px;
  height: 100px;
}
.statebe h2 {
  font-size: 14px;
}
.statebe p {
  font-size: 10px;
}
</style>

