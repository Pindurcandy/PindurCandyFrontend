<template>
  <div>
    <div v-if="isLoading" class="text-center">
      <div class="spinner-border" role="status">
        <span class="sr-only">Loading...</span>
      </div>
    </div>
    <div v-else class="container">
      <div class="row">
        <div
          class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4"
          v-for="item in paginatedItems"
          :key="item.id"
        >
          <div class="card">
            <div>
              <img
              :src="'data:image/png;base64,' + item.kep"
              class="card-img-top kepkeret"
              alt="Item Image"
              style="object-fit: cover"
              />
            </div>
            
            <div class="card-body">
              <h5 class="card-title">{{ item.termekNev }}</h5>
              <p class="card-text text-truncate" style="max-height: 2.4rem; overflow: hidden;" :title="item.leiras">{{ item.leiras }}</p>
              <p class="card-text">{{ item.ar }} Ft</p>
              <p class="card-text">{{ item.darab }} db</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div>
      <nav aria-label="Page navigation example">
        <ul class="pagination justify-content-center">
          <li class="page-item" @click="currentPage--" :disabled="currentPage === 1">
            <a class="page-link" href="#">Previous</a>
          </li>
          <li class="page-item" v-for="pageNumber in pageCount" :key="pageNumber" :class="{ 'active': currentPage === pageNumber }">
            <a class="page-link" href="#" @click="currentPage = pageNumber">{{ pageNumber }}</a>
          </li>
          <li class="page-item" @click="currentPage++" :disabled="currentPage === pageCount">
            <a class="page-link" href="#">Next</a>
          </li>
        </ul>
      </nav>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "TemekekView",
  components: {},
  data() {
    return {
      isLoading: true,
      currentPage: 1,
      pageSize: 9,
      items: [
        {
          kep: "",
          leiras: "",
          ar: 0,
          darab: 0,
          termekNev: "",
          aktiv: 0,
        },
      ],
    };
  },
  methods: {
    refreshData() {
      // You can use this method to refresh the data
      // whenever you need to update the items array.
      // For example, you can call this method after
      // adding, editing or deleting items.
    },
    adatlekeres() {
      axios
        .get("https://localhost:5001/Termekek/basic")
        .then((response) => {
          if (response.status == 200) {
            let d = response.data;
            console.log(d);
            if (this.items.aktiv != "0") {
              this.items = d;
              this.refreshData();
            } else {
              alert("Error");
            }
          }
          this.isLoading = false; // Set isLoading to false after data is loaded
        });
    },
  },
  mounted: function () {
    this.adatlekeres();
  },
  computed: {
    pageCount() {
      return Math.ceil(this.items.length / this.pageSize);
    },
    paginatedItems() {
      const startIndex = (this.currentPage - 1) * this.pageSize;
      return this.items.slice(startIndex, startIndex + this.pageSize);
    },
  },
};
</script>

<style scoped>
.card {
  margin-bottom: 20px;
}

.kepkeret {
  border: 4px solid #d439dc;
  display: block;
  margin-left: auto;
  margin-right: auto;
  padding: 2px;
  border-radius: 50%;
  border-top-color: #22daff;
  border-left-color: #22daff;
  width: 300px;
  height: 300px;
}
</style>