<template>
  <div>
    <ul>
      <li v-for="item in paginatedItems" :key="item.id">
        <div>{{ item.termekNev }}</div>
        <div>{{ item.ar }} Ft</div>
        <div>{{ item.darab }} db</div>
        <div>{{ item.leiras }}</div>
        <div><img :src="item.kep" /></div>
      </li>
    </ul>
    <div>
      <button @click="currentPage--" :disabled="currentPage === 1">
        Previous
      </button>
      <button @click="currentPage++" :disabled="currentPage === pageCount">
        Next
      </button>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  name: "TemekekView",
  components: {},
  data() {
    return {
      currentPage: 1,
      pageSize: 10,
      items: [
        {
          kep: "",
          leiras: "",
          ar: 0,
          darab: 0,
          termekNev: "",
        },
      ],
    };
  },
  methods: {
    refreshData() {
      // You can use this method to refresh the data
      // whenever you need to update the items array.
      // For example, you can call this method after
      // adding, editing or deleting items.
    },
    adatlekeres() {
      axios
        .get("https://192.168.50.39:5001/Termekek/basic")
        .then((response) => {
          if (response.status == 200) {
            let d = response.data;
            console.log(d);
            if (d.aktiv != "0") {
              this.items.id = d.id;
              this.items.kep = d.kep;
              this.items.termekNev = d.termekNev;
              this.items.leiras = d.leiras;
              this.items.ar = d.ar;
              this.items.darab = d.darab;
              this.refreshData();
            } else {
              alert("Error");
            }
          }
        });
    },
  },
  mounted: function () {
    this.adatlekeres();
  },
  computed: {
    pageCount() {
      return Math.ceil(this.items.length / this.pageSize);
    },
    paginatedItems() {
      const startIndex = (this.currentPage - 1) * this.pageSize;
      return this.items.slice(startIndex, startIndex + this.pageSize);
    },
  },
};
</script>